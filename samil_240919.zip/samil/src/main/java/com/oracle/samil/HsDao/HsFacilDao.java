package com.oracle.samil.HsDao;

import java.util.List;

import com.oracle.samil.Amodel.Facility;

public interface HsFacilDao {

	List<Facility> facilSortList();
	
}
