package com.oracle.samil.HsDao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.oracle.samil.Amodel.Facility;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class HsFacilDaoImpl implements HsFacilDao {
	
	@Autowired
	private final SqlSession session;
	
	@Override
	public List<Facility> facilSortList() {
		List<Facility> facilSort = null;
		System.out.println("HsFacilDaoImpl facilSortList Start...");
		
		try {
			facilSort = session.selectList("tkFacilSort");
		} catch (Exception e) {
			System.out.println("HsFacilDaoImpl facilSortList e.getMessage()-> "+e.getMessage());
		}
		return facilSort;
	}

}
