package com.oracle.samil.Acontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oracle.samil.Amodel.Event;
import com.oracle.samil.Amodel.FacilApprove;
import com.oracle.samil.Amodel.Facility;
import com.oracle.samil.Amodel.Reservation;
import com.oracle.samil.HsService.HsResService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequiredArgsConstructor
@Slf4j
@RequestMapping(value="/hs")
public class HsReservationController {
	@Autowired
	private HsResService hrs;
		
	@GetMapping(value = "/res")
	public String res (Reservation res, FacilApprove faAp ,Model model){
		System.out.println("HsReservationController res start...");
		
		//예약대기 조회
		List<Reservation> listload = hrs.listload(res);
		model.addAttribute("facilLoad", listload);
		
		//예약완료 조회
		List<FacilApprove> listFacilAcc = hrs.listFacilAcc(faAp);
		model.addAttribute("facilAcc", listFacilAcc);
		
		//예약반려 조회
		List<FacilApprove> listFacilRej = hrs.listFacilRej(faAp);
		model.addAttribute("facilRej", listFacilRej);
		
		System.out.println("HsReservationController res End...");
		return "hs/res";
	}
	
	@GetMapping(value = "/resWriteForm")
	public String res_resWriteForm (Model model){
		System.out.println("HsReservationController res_resWriteForm start...");
		List<Facility> facilSort = hrs.facilSortlist();
		model.addAttribute("facilSort", facilSort);
		System.out.println("HsReservationController res_resWriteForm facilSort.size()-> "+facilSort.size());
		
		System.out.println("HsReservationController res_resWriteForm End...");
		return "hs/resWriteForm";
	}
	
	@PostMapping(value = "writeReserv")
	public String res_writeReserv (Reservation res, Model model) {
		System.out.println("HsReservationController res_writeReserv start...");
		 int insertResult = hrs.insertReserv(res);
		System.out.println("HsReservationController res_writeReserv End...");
		if (insertResult > 0) {
			return "redirect:/hs/res";
		} else {
			model.addAttribute("msg", "입력 실패! 확인해보세요");
			return "forward:hs/resWriteForm";
		}
	}
	
	@RequestMapping("/resUpdate")
	public String res_resUpdateForm (Reservation res1, Model model){
		System.out.println("HsReservationController res_resUpdateForm start...");
		List<Facility> facilSort = hrs.facilSortlist();
		model.addAttribute("facilSort", facilSort);
		System.out.println("HsReservationController res_resUpdateForm facilSort.size()-> "+facilSort.size());
		
		Reservation res = hrs.detailRes(res1.getResCode());
		System.out.println("HsReservationController res_resUpdateForm res->"+res);
		
		model.addAttribute("reservation", res);
		return "hs/resUpdate";
	}
	
	
	@PostMapping(value = "resRealUpdate")
	public String res_resUpdate (Reservation res, Model model){
		System.out.println("HsReservationController res_resUpdate start...");
		System.out.println("HsReservationController res_resUpdate res-> "+res);
		
		int updateCount = hrs.updateReserv(res);
		System.out.println("HsReservationController res_resUpdate updateCount-> "+updateCount);
		model.addAttribute("uptCnt", updateCount);
		
		System.out.println("HsReservationController res_resUpdate End...");
		return "redirect:/hs/res";
	}
	
	@PostMapping("/deleteRes")
	public String res_resDelete (Reservation res, Model model) {
		System.out.println("HsReservationController res_resDelete Start...");
		int result = hrs.deleteRes(res.getResCode());
		System.out.println("HsReservationController res_resDelete End...");
		return "redirect:/hs/res";
	}
	
	
	@GetMapping(value = "/resDetail")
	public String res_resDetail (){
		System.out.println("HsReservationController res_resDetail start...");
		return "hs/resDetail";
	}
	
	
	@GetMapping(value = "/admin_res")
	public String res_admin (){
		System.out.println("HsReservationController res_admin start...");
		return "hs/admin_res";
	}
	
	@GetMapping(value = "/admin_resWriteForm")
	public String res_admin_resWriteForm (){
		System.out.println("HsReservationController res_admin_resWriteForm start...");
		return "hs/admin_resWriteForm";
	}
	
	@GetMapping(value = "/admin_resUpdate")
	public String res_admin_resUpdate (){
		System.out.println("HsReservationController res_admin_resUpdate start...");
		return "hs/admin_resUpdate";
	}
	
	@GetMapping(value = "/admin_resReason")
	public String res_admin_resReason (){
		System.out.println("HsReservationController res_admin_resReason start...");
		return "hs/admin_resReason";
	}
	
	
}
