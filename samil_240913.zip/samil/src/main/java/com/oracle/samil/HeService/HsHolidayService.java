package com.oracle.samil.HeService;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HsHolidayService {
	
	@Value("${holiday.api.url}")  // API URL을 application.properties에서 주입받습니다.
    private String apiUrl;

    @Value("${holiday.api.key}")  // API Key를 application.properties에서 주입받습니다.
    private String apiKey;

    private final RestTemplate restTemplate;

    public String getHolidays(String countryCode, int year) {
        String url = UriComponentsBuilder.fromHttpUrl(apiUrl)
                .pathSegment("PublicHolidays")
                .queryParam("country", countryCode)
                .queryParam("year", year)
                .queryParam("key", apiKey)
                .toUriString();

        try {
            return restTemplate.getForObject(url, String.class);
        } catch (Exception e) {
            e.printStackTrace();
            return "{\"error\": \"Failed to fetch holidays\"}";
        }
    }
	
}
