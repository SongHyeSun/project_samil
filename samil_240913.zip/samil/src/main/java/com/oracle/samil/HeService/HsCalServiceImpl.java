package com.oracle.samil.HeService;

import java.util.List;

import org.springframework.stereotype.Service;

import com.oracle.samil.Amodel.Event;
import com.oracle.samil.HsDao.HsCalDao;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HsCalServiceImpl implements HsCalService {
	private final HsCalDao hcd;

	@Override
	public List<Event> listEvent(Event event) {
		List<Event> eventList = null;
		System.out.println("HsCalServiceImpl listEvent Start...");
		eventList = hcd.listEvent(event);
		System.out.println("HsCalServiceImpl listEvent End...");
		return eventList;
	}

	@Override
	public Event detailEvent(int eventId) {
		System.out.println("HsCalServiceImpl detailEvent Start...");
		Event event = hcd.detailEvent(eventId);
		
		System.out.println("HsCalServiceImpl detailEvent End...");
		return event;
	}

	@Override
	public int updateEvent(Event event) {
		System.out.println("HsCalServiceImpl updateEvent Start...");
		int updateCount=0;
		updateCount = hcd.updateEvent(event);
		System.out.println("HsCalServiceImpl updateEvent updateCount -> "+updateCount);
		System.out.println("HsCalServiceImpl updateEvent After...");
		return updateCount;
	}

	@Override
	public int insertEvent(Event event) {
		System.out.println("HsCalServiceImpl insertEvent Start...");
		int result = hcd.insertEvent(event);
		
		System.out.println("HsCalServiceImpl insertEvent result-> "+result);
		System.out.println("HsCalServiceImpl insertEvent hcd.insertEvent After...");
		return result;
	}
}
