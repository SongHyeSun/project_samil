package com.oracle.samil.Acontroller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oracle.samil.HeService.HsResService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequiredArgsConstructor
@Slf4j
@RequestMapping(value="/hs")
public class HsReservationController {
	
	private HsResService hrs;
		
	@GetMapping(value = "/res")
	public String res (){
		System.out.println("HsReservationController res start...");
		return "hs/res";
	}
	
	@GetMapping(value = "/resDetail")
	public String res_resDetail (){
		System.out.println("HsReservationController res_resDetail start...");
		return "hs/resDetail";
	}
	
	
	@GetMapping(value = "/resWriteForm")
	public String res_resWriteForm (){
		System.out.println("HsReservationController res_resWriteForm start...");
		return "hs/resWriteForm";
	}
	
	@GetMapping(value = "/resUpdate")
	public String res_resUpdate (){
		System.out.println("HsReservationController res_resUpdate start...");
		return "hs/resUpdate";
	}
	
	@GetMapping(value = "/admin_res")
	public String res_admin (){
		System.out.println("HsReservationController res_admin start...");
		return "hs/admin_res";
	}
	
	@GetMapping(value = "/admin_resWriteForm")
	public String res_admin_resWriteForm (){
		System.out.println("HsReservationController res_admin_resWriteForm start...");
		return "hs/admin_resWriteForm";
	}
	
	@GetMapping(value = "/admin_resUpdate")
	public String res_admin_resUpdate (){
		System.out.println("HsReservationController res_admin_resUpdate start...");
		return "hs/admin_resUpdate";
	}
	
	@GetMapping(value = "/admin_resReason")
	public String res_admin_resReason (){
		System.out.println("HsReservationController res_admin_resReason start...");
		return "hs/admin_resReason";
	}
	
	
}
