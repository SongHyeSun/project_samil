package com.oracle.samil.HeService;

import java.util.List;

import com.oracle.samil.Amodel.Event;

public interface HsCalService {

	List<Event> listEvent(Event event);
	Event 		detailEvent(int eventId);
	int 		updateEvent(Event event);
	int 		insertEvent(Event event);

}
