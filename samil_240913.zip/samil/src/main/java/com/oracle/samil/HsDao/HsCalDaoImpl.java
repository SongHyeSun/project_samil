package com.oracle.samil.HsDao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.oracle.samil.Amodel.Event;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class HsCalDaoImpl implements HsCalDao {
	
	private final SqlSession session;

	@Override
	public List<Event> listEvent(Event event) {
		List<Event> eventList = null;
		System.out.println("HsCalDaoImpl listEvent Start...");
		try {
			eventList = session.selectList("tkEventListAll",event);
			System.out.println("HsCalDaoImpl listEvent eventList.size()-> "+eventList.size());
		} catch (Exception e) {
			System.out.println("HsCalDaoImpl listEvent e.getMessage()-> "+e.getMessage());
		}
		
		System.out.println("HsCalDaoImpl listEvent End...");
		return eventList;
	}

	@Override
	public Event detailEvent(int eventId) {
		Event event = new Event();
		System.out.println("HsCalDaoImpl detailEvent Start...");
		try {
			event = session.selectOne("tkEventSelOne", eventId);
			System.out.println("HsCalDaoImpl detailEvent event-> "+event);
			
		} catch (Exception e) {
			System.out.println("HsCalDaoImpl detailEvent e.getMessage()-> "+e.getMessage());
		}
		System.out.println("HsCalDaoImpl detailEvent End...");
		return event;
	}

	@Override
	public int updateEvent(Event event) {
		int updateCount = 0;
		System.out.println("HsCalDaoImpl updateEvent Start...");
		
		
		try {
			updateCount = session.update("tkEventUpdate", event);
			System.out.println("HsCalDaoImpl updateEvent updateCount-> "+updateCount);
		} catch (Exception e) {
			System.out.println("HsCalDaoImpl updateEvent e.getMessage()-> "+e.getMessage());
		}
		return updateCount;
	}

	@Override
	public int insertEvent(Event event) {
		int result = 0;
		System.out.println("HsCalDaoImpl insertEvent Start...");
		try {
			result = session.insert("tkEventInsert", event);
		} catch (Exception e) {
			System.out.println("HsCalDaoImpl insertEvent e.getMessage()-> "+e.getMessage());
		}
		return result;
	}
	
}
