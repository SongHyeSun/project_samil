package com.oracle.samil.Acontroller;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oracle.samil.Amodel.Event;
import com.oracle.samil.HeService.HsCalService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequiredArgsConstructor
@Slf4j
@RequestMapping(value="/hs")
public class HsCalController {
	
	private final HsCalService hcs;
	
	@GetMapping(value = "/cal")
	public String cal (Event event, Model model){
		System.out.println("hsCalController cal Start");
		// 추가된 달력 정보 계산 로직
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        int month = calendar.get(Calendar.MONTH);
        int year = calendar.get(Calendar.YEAR);

        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        int daysInMonth = calendar.get(Calendar.DAY_OF_MONTH);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        int startDay = calendar.get(Calendar.DAY_OF_WEEK);

        Map<String, Object> calendarData = new HashMap<>();
        calendarData.put("month", month);
        calendarData.put("year", year);
        calendarData.put("daysInMonth", daysInMonth);
        calendarData.put("startDay", startDay);

        model.addAttribute("calendarData", calendarData);
		
        List<Event> listEvent = hcs.listEvent(event);
        
        model.addAttribute("listEvent", listEvent);
        
        System.out.println("hsCalController cal End....");
		return "hs/cal";
	}
	
	@RequestMapping(value = "listEvent")
	public String listEvent (Event event, Model model){
		System.out.println("hsCalController listEvent Start");
		// 추가된 달력 정보 계산 로직
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        int month = calendar.get(Calendar.MONTH);
        int year = calendar.get(Calendar.YEAR);

        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        int daysInMonth = calendar.get(Calendar.DAY_OF_MONTH);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        int startDay = calendar.get(Calendar.DAY_OF_WEEK);

        Map<String, Object> calendarData = new HashMap<>();
        calendarData.put("month", month);
        calendarData.put("year", year);
        calendarData.put("daysInMonth", daysInMonth);
        calendarData.put("startDay", startDay);

        model.addAttribute("calendarData", calendarData);
		
        List<Event> listEvent = hcs.listEvent(event);
        
        model.addAttribute("listEvent", listEvent);
        
        System.out.println("listEvent cal End....");
		return "hs/cal";
	}
	
	@GetMapping(value = "/calDetail")
	public String cal_calDetail (Event event1, Model model){
		System.out.println("hsCalController cal_calDetail Start");
		
		Event event = hcs.detailEvent(event1.getEventId());
		System.out.println("event -> "+event1);
		model.addAttribute("event", event);
		
		System.out.println("hsCalController cal_calDetail End...");
		
		return "hs/calDetail";
	}
	
	@GetMapping(value = "/calUpdate")
	public String cal_calUpdateForm (Event event1, Model model) {
		System.out.println("hsCalController cal_calUpdateForm Start...");
		Event event = hcs.detailEvent(event1.getEventId());
		System.out.println("hsCalController cal_calUpdateForm event->"+event);
		
		String eventStartdate="";
		if (event.getEventStartdate() != null) {
			eventStartdate = event.getEventStartdate().substring(0,10);
			event.setEventStartdate(eventStartdate);
		}
		
		String eventEnddate="";
		if (event.getEventEnddate() != null) {
			eventEnddate = event.getEventEnddate().substring(0,10);
			event.setEventEnddate(eventEnddate);
		}
		
		System.out.println("eventStartdate-> "+eventStartdate);
		System.out.println("eventEnddate-> "+eventEnddate);
		model.addAttribute("event", event);
		System.out.println("hsCalController cal_calUpdateForm End...");
		return "hs/calUpdate";
	}
	
	
	@PostMapping(value = "updateEvent")
	public String cal_calUpdate (Event event, Model model) {
		System.out.println("hsCalController cal_calUpdate Start...");
		System.out.println("hsCalController cal_calUpdate event->"+event);
		int updateCount = hcs.updateEvent(event);
		System.out.println("hsCalController cal_calUpdate updateCount-> "+updateCount);
		model.addAttribute("uptCnt", updateCount);
		int eventid = event.getEventId();
		System.out.println("hsCalController cal_calUpdate End...");
		return "redirect:/hs/calDetail?eventId="+eventid;
	}
	
	@GetMapping(value = "/calWriteForm")
	public String cal_calWriteForm (Model model){
		System.out.println("hsCalController cal_calWriteForm Start");
		
		//일정 분류
		Map<Integer, String> cateMap = new HashMap<>();
		cateMap.put(100, "회사일정");
		cateMap.put(110, "공유일정");
		cateMap.put(120, "개인일정");
		cateMap.put(130, "연차");
		
		model.addAttribute("cateMap", cateMap);
		
		return "hs/calWriteForm";
	}
	
	@PostMapping(value = "writeEvent")
	public String cal_writeEvent (Event event, Model model){
		System.out.println("hsCalController cal_writeEvent Start...");
		
		int insertResult = hcs.insertEvent(event);
		System.out.println("hsCalController cal_writeEvent End...");
		if (insertResult > 0) return "redirect:hs/listEvent";
		else {
			model.addAttribute("msg", "입력 실패! 확인해보세요");
			return "forward:hs/calWriteForm";
		}
	}
	
	@GetMapping(value = "/calDelete")
	public String cal_calDelete (){
		System.out.println("hsCalController cal_calDelete Start");
		return "hs/calDelete";
	}
	
	
	@GetMapping(value = "/calWriteForm_list")
	public String cal_calWriteForm_list (){
		System.out.println("hsCalController cal_calWriteForm_list Start");
		return "hs/calWriteForm_list";
	}
		
	@GetMapping(value = "/admin_cal")
	public String cal_admin (){
		System.out.println("hsCalController cal_admin Start");
		return "hs/admin_cal";
	}
	
	@GetMapping(value = "/admin_calDetail")
	public String cal_admin_calDetail (){
		System.out.println("hsCalController cal_admin_calDetail Start");
		return "hs/admin_calDetail";
	}
	
	@GetMapping(value = "/admin_calUpdate")
	public String cal_admin_calUpdate (){
		System.out.println("hsCalController cal_admin_calUpdate Start");
		return "hs/admin_calUpdate";
	}
	
	@GetMapping(value = "/admin_calWriteForm")
	public String cal_admin_calWriteForm (){
		System.out.println("hsCalController cal_admin_calWriteForm Start");
		return "hs/admin_calWriteForm";
	}
	
}
