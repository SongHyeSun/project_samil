package com.oracle.samil.HsDao;

public interface HsResDao {

}
