package com.oracle.samil.HeService;

import org.springframework.stereotype.Service;

import com.oracle.samil.HsDao.HsResDao;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HsResServiceImpl implements HsResService {
	private final HsResDao hrd;
}
