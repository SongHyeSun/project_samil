package com.oracle.samil.Acontroller;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.oracle.samil.HeService.HsCalService;
import com.oracle.samil.HeService.HsHolidayService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value="/hs")
@RequiredArgsConstructor
public class HsCalRestController {
	
	private final HsHolidayService holidayService;


    @GetMapping("/holidays")
    public ResponseEntity<?> getHolidays(@RequestParam(name = "countryCode") String countryCode, @RequestParam(name = "year") int year) {
    	log.info("Fetching holidays for countryCode: {} and year: {}", countryCode, year);
        String holidaysJson = holidayService.getHolidays(countryCode, year);
        return ResponseEntity.ok(holidaysJson);
    }
}

