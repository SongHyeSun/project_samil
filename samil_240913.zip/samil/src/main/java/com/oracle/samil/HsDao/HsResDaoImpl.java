package com.oracle.samil.HsDao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class HsResDaoImpl implements HsResDao {
	
	private final SqlSession session;
}
