package com.oracle.samil.HsDao;

import java.util.List;

import com.oracle.samil.Amodel.Event;

public interface HsCalDao {

	List<Event> listEvent(Event event);
	Event 		detailEvent(int eventId);
	int 		updateEvent(Event event);
	int 		insertEvent(Event event);

}
