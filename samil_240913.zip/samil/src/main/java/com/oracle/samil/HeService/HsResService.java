package com.oracle.samil.HeService;

public interface HsResService {

}
