package com.oracle.samil.TrDao;

import com.oracle.samil.Amodel.Emp;

public interface EmpDao {

	Emp findEmpbyEmpno(String empno);
	
	

}
