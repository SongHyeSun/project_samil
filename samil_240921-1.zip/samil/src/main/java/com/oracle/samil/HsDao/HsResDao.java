package com.oracle.samil.HsDao;

import java.util.List;

import com.oracle.samil.Amodel.FacilApprove;
import com.oracle.samil.Amodel.Facility;
import com.oracle.samil.Amodel.Reservation;

public interface HsResDao {

	List<Reservation> 	listload(Reservation res);
	List<FacilApprove>	listFacilAcc(FacilApprove faAp);
	List<FacilApprove> 	listFacilRej(FacilApprove faAp);
	int 				insertReserv(Reservation res);
	int 				updateReserv(Reservation res);
	Reservation 		detailRes(int resCode);
	int 				deleteRes(int resCode);
	List<Reservation> 	listfacil(Reservation res);
	int 				insertFacil(FacilApprove facAp);
	int 				updateFac(FacilApprove facAp);

}
