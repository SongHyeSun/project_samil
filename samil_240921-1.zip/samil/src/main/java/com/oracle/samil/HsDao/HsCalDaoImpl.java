package com.oracle.samil.HsDao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.oracle.samil.Amodel.Attendee;
import com.oracle.samil.Amodel.Event;
import com.oracle.samil.Amodel.Reservation;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class HsCalDaoImpl implements HsCalDao {
	
	@Autowired
	private final SqlSession session;

	@Override
	public List<Event> listEvent(Event event) {
		List<Event> eventList = null;
		System.out.println("HsCalDaoImpl listEvent Start...");
		try {
			eventList = session.selectList("tkEventListAll",event);
			System.out.println("HsCalDaoImpl listEvent eventList.size()-> "+eventList.size());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsCalDaoImpl listEvent e.getMessage()-> "+e.getMessage());
		}
		
		System.out.println("HsCalDaoImpl listEvent End...");
		return eventList;
	}

	@Override
	public Event detailEvent(int eventId) {
		Event event = new Event();
		System.out.println("HsCalDaoImpl detailEvent Start...");
		try {
			event = session.selectOne("tkEventSelOne", eventId);
			System.out.println("HsCalDaoImpl detailEvent event-> "+event);
			
		} catch (Exception e) {
			System.out.println("HsCalDaoImpl detailEvent e.getMessage()-> "+e.getMessage());
		}
		System.out.println("HsCalDaoImpl detailEvent End...");
		return event;
	}

	@Override
	public int updateEvent(Event event) {
		int updateCount = 0;
		System.out.println("HsCalDaoImpl updateEvent Start...");
		
		
		try {
			updateCount = session.update("tkEventUpdate", event);
			System.out.println("HsCalDaoImpl updateEvent updateCount-> "+updateCount);
		} catch (Exception e) {
			System.out.println("HsCalDaoImpl updateEvent e.getMessage()-> "+e.getMessage());
		}
		return updateCount;
	}

	@Override
	public int insertEvent(Event event) {
		int result = 0;
		System.out.println("HsCalDaoImpl insertEvent Start...");
		try {
			result = session.insert("tkEventInsert", event);
			System.out.println("HsCalDaoImpl insertEvent event-> "+event);
		} catch (Exception e) {
			System.out.println("HsCalDaoImpl insertEvent e.getMessage()-> "+e.getMessage());
		}
		return result;
	}

	@Override
	public int deleteEvent(Event event) {
		int result = 0;
		System.out.println("HsCalDaoImpl deleteEvent Start...");
		try {
			result = session.update("tkEventDelupt", event);
			System.out.println("HsCalDaoImpl updateEvent updateCount-> "+result);
		} catch (Exception e) {
			System.out.println("HsCalDaoImpl deleteEvent e.getMessage()-> "+e.getMessage());
		}
		return result;
	}

	@Override
	public List<Attendee> listReqAtten(Attendee attendee) {
		List<Attendee> listReqAttendee = null;
		System.out.println("HsCalDaoImpl listReqAtten Start...");
		try {
			listReqAttendee = session.selectList("tkReqAttList",attendee);
			System.out.println("HsCalDaoImpl listReqAtten listReqAttendee.size()-> "+listReqAttendee.size());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsCalDaoImpl listReqAtten e.getMessage()-> "+e.getMessage());
		}
		
		System.out.println("HsCalDaoImpl listReqAtten End...");
		return listReqAttendee;
	}


	@Override
	public int updateAttAcc(Attendee attendee) {
		int updateCount = 0;
		System.out.println("HsCalDaoImpl updateAttAcc Start...");
		
		
		try {
			updateCount = session.update("tkAttAccupdate", attendee);
			System.out.println("HsCalDaoImpl updateAttAcc updateCount-> "+updateCount);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsCalDaoImpl updateAttAcc e.getMessage()-> "+e.getMessage());
		}
		return updateCount;
	}

	@Override
	public int updateAttRej(Attendee attendee) {
		int updateCount = 0;
		System.out.println("HsCalDaoImpl updateAttRej Start...");
		
		
		try {
			updateCount = session.update("tkAttRejupdate", attendee);
			System.out.println("HsCalDaoImpl updateAttRej updateCount-> "+updateCount);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsCalDaoImpl updateAttRej e.getMessage()-> "+e.getMessage());
		}
		return updateCount;
	}

	@Override
	public List<Attendee> listResAtten(Attendee attendee) {
		List<Attendee> listResAttendee = null;
		System.out.println("HsCalDaoImpl listResAtten Start...");
		try {
			listResAttendee = session.selectList("tkResAttList",attendee);
			System.out.println("HsCalDaoImpl listResAtten listResAttendee.size()-> "+listResAttendee.size());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsCalDaoImpl listResAtten e.getMessage()-> "+e.getMessage());
		}
		
		System.out.println("HsCalDaoImpl listResAtten End...");
		return listResAttendee;
	}
	
	@Override
	public int eventRestore(Event event) {
		int updateCount = 0;
		System.out.println("HsCalDaoImpl eventRestore Start...");
		
		
		try {
			updateCount = session.update("tkeventRestore", event);
			System.out.println("HsCalDaoImpl eventRestore updateCount-> "+updateCount);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsCalDaoImpl eventForever e.getMessage()-> "+e.getMessage());
		}
		return updateCount;
	}

	@Override
	public int eventForever(int eventId) {
		int result = 0;
		System.out.println("HsCalDaoImpl eventForever Start...");
		System.out.println("HsCalDaoImpl eventForever eventId->" +eventId);
		try {
			result = session.delete("tkEventDelete", eventId);
			System.out.println("HsCalDaoImpl deleteEvent result-> "+result);
		} catch (Exception e) {
			System.out.println("HsCalDaoImpl deleteEvent e.getMessage()-> "+e.getMessage());
		}
		return result;
	}

	@Override
	public List<Event> listDelete(Event event) {
		List<Event> listDelete = null;
		System.out.println("HsCalDaoImpl listDelete Start...");
		try {
			listDelete = session.selectList("tkEventListDel",event);
			System.out.println("HsCalDaoImpl listDelete listDelete.size()-> "+listDelete.size());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsCalDaoImpl listDelete e.getMessage()-> "+e.getMessage());
		}
		
		System.out.println("HsCalDaoImpl listDelete End...");
		return listDelete;
	}

	@Override
	public List<Event> listAdEve(Event event) {
		List<Event> eventAdminList = null;
		System.out.println("HsCalDaoImpl listAdEve Start...");
		try {
			eventAdminList = session.selectList("tkEventAdList",event);
			System.out.println("HsCalDaoImpl listAdEve eventAdminList.size()-> "+eventAdminList.size());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsCalDaoImpl listAdEve e.getMessage()-> "+e.getMessage());
		}
		
		System.out.println("HsCalDaoImpl listAdEve End...");
		return eventAdminList;
	}

	@Override
	public Event detailAdEvent(int eventId) {
		Event event = new Event();
		System.out.println("HsCalDaoImpl detailAdEvent Start...");
		try {
			event = session.selectOne("tkEventAdSelOne", eventId);
			System.out.println("HsCalDaoImpl detailAdEvent event-> "+event);
			
		} catch (Exception e) {
			System.out.println("HsCalDaoImpl detailAdEvent e.getMessage()-> "+e.getMessage());
		}
		System.out.println("HsCalDaoImpl detailAdEvent End...");
		return event;
	}

	@Override
	public int deleteAdEvent(int eventId) {
		
		int result = 0;
		System.out.println("HsCalDaoImpl deleteAdEvent Start...");
		System.out.println("HsCalDaoImpl deleteAdEvent eventId->" +eventId);
		try {
			result = session.delete("tkEventAdDel", eventId);
			System.out.println("HsCalDaoImpl deleteAdEvent result-> "+result);
		} catch (Exception e) {
			System.out.println("HsCalDaoImpl deleteAdEvent e.getMessage()-> "+e.getMessage());
		}
		return result;
	}

	
}
