package com.oracle.samil.Acontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oracle.samil.Amodel.FacilApprove;
import com.oracle.samil.Amodel.Reservation;
import com.oracle.samil.HsService.HsResService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequiredArgsConstructor
@Slf4j
@RequestMapping(value="/hs")
public class HsReservationController {
	@Autowired
	private HsResService hrs;
		
	@GetMapping(value = "/res")
	public String res (Reservation res, FacilApprove faAp ,Model model){
		System.out.println("HsReservationController res start...");
		
		//예약대기 조회
		List<Reservation> listload = hrs.listload(res);
		model.addAttribute("facilLoad", listload);
		
		//예약완료 조회
		List<FacilApprove> listFacilAcc = hrs.listFacilAcc(faAp);
		model.addAttribute("facilAcc", listFacilAcc);
		
		//예약반려 조회
		List<FacilApprove> listFacilRej = hrs.listFacilRej(faAp);
		model.addAttribute("facilRej", listFacilRej);
		
		System.out.println("HsReservationController res End...");
		return "hs/res";
	}
	
	@GetMapping(value = "/resUpdate")
	public String res_resUpdateForm (){
		System.out.println("HsReservationController res_resUpdateForm start...");
		return "hs/resUpdate";
	}
	
	@GetMapping(value = "resRealUpdate")
	public String res_resUpdate (){
		System.out.println("HsReservationController res_resUpdate start...");
		return "redirect:/hs/res";
	}
	
	@GetMapping(value = "/resDetail")
	public String res_resDetail (){
		System.out.println("HsReservationController res_resDetail start...");
		return "hs/resDetail";
	}
	
	
	@GetMapping(value = "/resWriteForm")
	public String res_resWriteForm (){
		System.out.println("HsReservationController res_resWriteForm start...");
		return "hs/resWriteForm";
	}
	
	@GetMapping(value = "/admin_res")
	public String res_admin (){
		System.out.println("HsReservationController res_admin start...");
		return "hs/admin_res";
	}
	
	@GetMapping(value = "/admin_resWriteForm")
	public String res_admin_resWriteForm (){
		System.out.println("HsReservationController res_admin_resWriteForm start...");
		return "hs/admin_resWriteForm";
	}
	
	@GetMapping(value = "/admin_resUpdate")
	public String res_admin_resUpdate (){
		System.out.println("HsReservationController res_admin_resUpdate start...");
		return "hs/admin_resUpdate";
	}
	
	@GetMapping(value = "/admin_resReason")
	public String res_admin_resReason (){
		System.out.println("HsReservationController res_admin_resReason start...");
		return "hs/admin_resReason";
	}
	
	
}
