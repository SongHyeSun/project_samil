package com.oracle.samil.Acontroller;

import java.sql.Timestamp;
import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oracle.samil.Amodel.Attendee;
import com.oracle.samil.Amodel.Event;
import com.oracle.samil.HsService.HsCalService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequiredArgsConstructor
@Slf4j
@RequestMapping(value="/hs")
public class HsCalController {
	
	@Autowired
	private final HsCalService hcs;
	
	@GetMapping(value = "/cal")
	public String cal (Event event, Attendee attendee, Model model){
		System.out.println("hsCalController cal Start");
		// 추가된 달력 정보 계산 로직
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        int month = calendar.get(Calendar.MONTH);
        int year = calendar.get(Calendar.YEAR);

        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        int daysInMonth = calendar.get(Calendar.DAY_OF_MONTH);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        int startDay = calendar.get(Calendar.DAY_OF_WEEK);

        Map<String, Object> calendarData = new HashMap<>();
        calendarData.put("month", month);
        calendarData.put("year", year);
        calendarData.put("daysInMonth", daysInMonth);
        calendarData.put("startDay", startDay);

        model.addAttribute("calendarData", calendarData);
		
        //일정 list
        List<Event> listEvent = hcs.listEvent(event);
        
        model.addAttribute("listEvent", listEvent);
        
        // 공유일정 요청list
        List<Attendee> listRequestAtten = hcs.listReqAtten(attendee);
        
        model.addAttribute("listRequestAtten", listRequestAtten);		
        
        // 내 공유요청 사안
        List<Attendee> listResponseAtten = hcs.listResAtten(attendee);
        
      	Map<Integer, String> atteReMap = new HashMap<>();
      	atteReMap.put(100, "대기");
      	atteReMap.put(110, "승인");
      	atteReMap.put(120, "거부");
      	
      	model.addAttribute("atteReMap", atteReMap);
      	model.addAttribute("listResponseAtten", listResponseAtten);	
        
        
        		
        System.out.println("hsCalController cal End....");
		return "hs/cal";
	}
	
	@RequestMapping(value = "listEvent")
	public String listEvent (Event event, Attendee attendee, Model model){
		System.out.println("hsCalController cal Start");
		// 추가된 달력 정보 계산 로직
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        int month = calendar.get(Calendar.MONTH);
        int year = calendar.get(Calendar.YEAR);

        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        int daysInMonth = calendar.get(Calendar.DAY_OF_MONTH);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        int startDay = calendar.get(Calendar.DAY_OF_WEEK);

        Map<String, Object> calendarData = new HashMap<>();
        calendarData.put("month", month);
        calendarData.put("year", year);
        calendarData.put("daysInMonth", daysInMonth);
        calendarData.put("startDay", startDay);

        model.addAttribute("calendarData", calendarData);
		
        //일정 list
        List<Event> listEvent = hcs.listEvent(event);
        
        model.addAttribute("listEvent", listEvent);
        
        // 공유일정 요청list
        List<Attendee> listRequestAtten = hcs.listReqAtten(attendee);
        
        model.addAttribute("listRequestAtten", listRequestAtten);		
        		
        System.out.println("hsCalController cal End....");
		return "hs/cal";
	}
	
	@GetMapping(value = "/calDetail")
	public String cal_calDetail (Event event1, Model model){
		System.out.println("hsCalController cal_calDetail Start");
		
		Event event = hcs.detailEvent(event1.getEventId());
		System.out.println("event -> "+event1);
		model.addAttribute("event", event);
		
		System.out.println("hsCalController cal_calDetail End...");
		
		return "hs/calDetail";
	}
	
	@GetMapping(value = "/calUpdate")
	public String cal_calUpdateForm (Event event1, Model model) {
		System.out.println("hsCalController cal_calUpdateForm Start...");
		Event event = hcs.detailEvent(event1.getEventId());
		System.out.println("hsCalController cal_calUpdateForm event->"+event);
		
		model.addAttribute("event", event);
		System.out.println("hsCalController cal_calUpdateForm End...");
		return "hs/calUpdate";
	}
	
	
	@PostMapping(value = "updateEvent")
	public String cal_calUpdate (Event event, Model model) {
		System.out.println("hsCalController cal_calUpdate Start...");
		System.out.println("hsCalController cal_calUpdate event->"+event);
		int updateCount = hcs.updateEvent(event);
		System.out.println("hsCalController cal_calUpdate updateCount-> "+updateCount);
		model.addAttribute("uptCnt", updateCount);
		int eventid = event.getEventId();
		System.out.println("hsCalController cal_calUpdate End...");
		return "redirect:/hs/calDetail?eventId="+eventid;
	}
	
	@GetMapping(value = "/calWriteForm")
	public String cal_calWriteForm (Model model){
		System.out.println("hsCalController cal_calWriteForm Start");
		
		//일정 분류
		Map<Integer, String> cateMap = new HashMap<>();
		cateMap.put(100, "회사일정");
		cateMap.put(110, "공유일정");
		cateMap.put(120, "개인일정");
		cateMap.put(130, "연차");
		
		model.addAttribute("cateMap", cateMap);
		
		System.out.println("hsCalController cal_calWriteForm End...");
		return "hs/calWriteForm";
	}
	
	@PostMapping(value = "writeEvent")
	public String cal_writeEvent (Event event, Model model){
		System.out.println("hsCalController cal_writeEvent Start...");
		
		
		int insertResult = hcs.insertEvent(event);
		System.out.println("hsCalController cal_writeEvent End...");
		if (insertResult > 0) return "redirect:listEvent";
		else {
			model.addAttribute("msg", "입력 실패! 확인해보세요");
			return "forward:hs/calWriteForm";
		}
	}
	
	@RequestMapping(value = "deleteEvent")
	public String cal_deleteEvent(Event event, Model model) {
		System.out.println("hsCalController cal_deleteEvent Start...");
		
		int result = hcs.deleteEvent(event.getEventId());
		return "redirect:listEvent";
	}
	
	@PostMapping("updateAttAcc")
	public String cal_updateAttAccept (Attendee attendee, Model model) {
		System.out.println("hsCalController cal_updateAttAccept Start...");
		int updateCount = hcs.updateAttAcc(attendee);
		System.out.println("hsCalController cal_updateAttAccept updateCount-> "+updateCount);
		model.addAttribute("uptCnt", updateCount);
		System.out.println("hsCalController cal_updateAttAccept End...");
		return "redirect:/hs/cal";
	}
	
	@PostMapping("updateAttRej")
	public String cal_updateAttReject (Attendee attendee, Model model) {
		System.out.println("hsCalController cal_updateAttReject Start...");
		int updateCount = hcs.updateAttRej(attendee);
		System.out.println("hsCalController cal_updateAttReject updateCount-> "+updateCount);
		model.addAttribute("uptCnt", updateCount);
		System.out.println("hsCalController cal_updateAttReject End...");
		return "redirect:/hs/cal";
	}
	
	@GetMapping(value = "/calDelete")
	public String cal_calDelete (){
		System.out.println("hsCalController cal_calDelete Start");
		return "hs/calDelete";
	}
	
	
	@GetMapping(value = "/calWriteForm_list")
	public String cal_calWriteForm_list (){
		System.out.println("hsCalController cal_calWriteForm_list Start");
		return "hs/calWriteForm_list";
	}
		
	@GetMapping(value = "/admin_cal")
	public String cal_admin (){
		System.out.println("hsCalController cal_admin Start");
		return "hs/admin_cal";
	}
	
	@GetMapping(value = "/admin_calDetail")
	public String cal_admin_calDetail (){
		System.out.println("hsCalController cal_admin_calDetail Start");
		return "hs/admin_calDetail";
	}
	
	@GetMapping(value = "/admin_calUpdate")
	public String cal_admin_calUpdate (){
		System.out.println("hsCalController cal_admin_calUpdate Start");
		return "hs/admin_calUpdate";
	}
	
	@GetMapping(value = "/admin_calWriteForm")
	public String cal_admin_calWriteForm (){
		System.out.println("hsCalController cal_admin_calWriteForm Start");
		return "hs/admin_calWriteForm";
	}
	
}
