package com.oracle.samil.HsService;

import java.util.List;

import com.oracle.samil.Amodel.FacilApprove;
import com.oracle.samil.Amodel.Reservation;

public interface HsResService {

	List<Reservation> listload(Reservation res);
	List<FacilApprove> listFacilAcc(FacilApprove faAp);
	List<FacilApprove> listFacilRej(FacilApprove faAp);

}
