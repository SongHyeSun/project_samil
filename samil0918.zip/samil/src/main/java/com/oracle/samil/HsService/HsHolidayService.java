package com.oracle.samil.HsService;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HsHolidayService {
	
	@Value("${holiday.api.url}")  // API URL을 application.properties에서 주입받습니다.
    private String apiUrl;

    @Value("${holiday.api.key}")  // API Key를 application.properties에서 주입받습니다.
    private String apiKey;

    private final RestTemplate restTemplate;

    public String getHolidays(String countryCode, int year) {
    	String url = UriComponentsBuilder.fromHttpUrl(apiUrl)
                .queryParam("ServiceKey", apiKey)
                .queryParam("solYear", year)
                .queryParam("solMonth", "09") // 월을 지정해야 합니다. 예: "01" (1월)
                .queryParam("_type", "json")  // JSON 타입으로 응답을 받기 위해 추가합니다.
                .queryParam("numOfRows", 20)  // 한 페이지에 20개 결과를 받습니다.
                .toUriString();

        try {
            return restTemplate.getForObject(url, String.class);
        } catch (Exception e) {
            e.printStackTrace();
            return "{\"error\": \"Failed to fetch holidays\"}";
        }
    }
	
}
