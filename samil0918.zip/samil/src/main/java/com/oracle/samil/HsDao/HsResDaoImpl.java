package com.oracle.samil.HsDao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.oracle.samil.Amodel.Event;
import com.oracle.samil.Amodel.FacilApprove;
import com.oracle.samil.Amodel.Reservation;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class HsResDaoImpl implements HsResDao {
	
	@Autowired
	private final SqlSession session;

	@Override
	public List<Reservation> listload(Reservation res) {
		List<Reservation> listload = null;
		System.out.println("HsResDaoImpl listload Start...");
		try {
			listload = session.selectList("tkResListLoad",res);
			System.out.println("HsResDaoImpl listload listload.size()-> "+listload.size());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsResDaoImpl listload e.getMessage()-> "+e.getMessage());
		}
		
		System.out.println("HsResDaoImpl listload End...");
		return listload;
	}

	@Override
	public List<FacilApprove> listFacilAcc(FacilApprove faAp) {
		List<FacilApprove> listFacilAcc = null;
		System.out.println("HsResDaoImpl listFacilAcc Start...");
		try {
			listFacilAcc = session.selectList("tkResListAcc",faAp);
			System.out.println("HsResDaoImpl listFacilAcc listload.size()-> "+listFacilAcc.size());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsResDaoImpl listFacilAcc e.getMessage()-> "+e.getMessage());
		}
		
		System.out.println("HsResDaoImpl listFacilAcc End...");
		return listFacilAcc;
	}

	@Override
	public List<FacilApprove> listFacilRej(FacilApprove faAp) {
		List<FacilApprove> listFacilRej = null;
		System.out.println("HsResDaoImpl listFacilRej Start...");
		try {
			listFacilRej = session.selectList("tkResListRej",faAp);
			System.out.println("HsResDaoImpl listFacilRej listload.size()-> "+listFacilRej.size());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsResDaoImpl listFacilRej e.getMessage()-> "+e.getMessage());
		}
		
		System.out.println("HsResDaoImpl listFacilRej End...");
		return listFacilRej;
	}
}
