package com.oracle.samil.HsDao;

import java.util.List;

import com.oracle.samil.Amodel.FacilApprove;
import com.oracle.samil.Amodel.Reservation;

public interface HsResDao {

	List<Reservation> listload(Reservation res);

	List<FacilApprove> listFacilAcc(FacilApprove faAp);

	List<FacilApprove> listFacilRej(FacilApprove faAp);

}
