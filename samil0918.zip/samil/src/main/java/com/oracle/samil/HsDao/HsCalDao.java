package com.oracle.samil.HsDao;

import java.util.List;

import com.oracle.samil.Amodel.Attendee;
import com.oracle.samil.Amodel.Event;

public interface HsCalDao {

	List<Event> 	listEvent(Event event);
	Event 			detailEvent(int eventId);
	int 			updateEvent(Event event);
	int 			insertEvent(Event event);
	int 			deleteEvent(int eventId);
	List<Attendee> 	listReqAtten(Attendee attendee);
	int 			updateAttAcc(Attendee attendee);
	int 			updateAttRej(Attendee attendee);
	List<Attendee> 	listResAtten(Attendee attendee);

}
