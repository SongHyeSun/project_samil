package com.oracle.samil.HsService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oracle.samil.Amodel.FacilApprove;
import com.oracle.samil.Amodel.Reservation;
import com.oracle.samil.HsDao.HsResDao;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HsResServiceImpl implements HsResService {
	
	@Autowired
	private final HsResDao hrd;

	@Override
	public List<Reservation> listload(Reservation res) {
		List<Reservation> listload = null;
		System.out.println("HsResServiceImpl listload Start...");
		listload = hrd.listload(res);
		
		System.out.println("HsResServiceImpl listload After...");
		return listload;
	}

	@Override
	public List<FacilApprove> listFacilAcc(FacilApprove faAp) {
		List<FacilApprove> listFacilAcc = null;
		System.out.println("HsResServiceImpl listFacilAcc Start...");
		listFacilAcc = hrd.listFacilAcc(faAp);
		System.out.println("HsResServiceImpl listFacilAcc After...");
		
		return listFacilAcc;
	}

	@Override
	public List<FacilApprove> listFacilRej(FacilApprove faAp) {
		List<FacilApprove> listFacilRej = null;
		System.out.println("HsResServiceImpl listFacilRej Start...");
		listFacilRej = hrd.listFacilRej(faAp);
		System.out.println("HsResServiceImpl listFacilRej After...");
		
		return listFacilRej;
	}
}
