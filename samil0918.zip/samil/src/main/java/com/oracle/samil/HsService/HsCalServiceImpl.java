package com.oracle.samil.HsService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oracle.samil.Amodel.Attendee;
import com.oracle.samil.Amodel.Event;
import com.oracle.samil.HsDao.HsCalDao;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HsCalServiceImpl implements HsCalService {
	
	@Autowired
	private final HsCalDao hcd;

	@Override
	public List<Event> listEvent(Event event) {
		List<Event> eventList = null;
		System.out.println("HsCalServiceImpl listEvent Start...");
		eventList = hcd.listEvent(event);
		System.out.println("HsCalServiceImpl listEvent End...");
		return eventList;
	}

	@Override
	public Event detailEvent(int eventId) {
		System.out.println("HsCalServiceImpl detailEvent Start...");
		Event event = hcd.detailEvent(eventId);
		
		System.out.println("HsCalServiceImpl detailEvent End...");
		return event;
	}

	@Override
	public int updateEvent(Event event) {
		System.out.println("HsCalServiceImpl updateEvent Start...");
		int updateCount=0;
		updateCount = hcd.updateEvent(event);
		System.out.println("HsCalServiceImpl updateEvent updateCount -> "+updateCount);
		System.out.println("HsCalServiceImpl updateEvent After...");
		return updateCount;
	}

	@Override
	public int insertEvent(Event event) {
		System.out.println("HsCalServiceImpl insertEvent Start...");
		int result = hcd.insertEvent(event);
		
		System.out.println("HsCalServiceImpl insertEvent result-> "+result);
		System.out.println("HsCalServiceImpl insertEvent hcd.insertEvent After...");
		return result;
	}

	@Override
	public int deleteEvent(int eventId) {
		System.out.println("HsCalServiceImpl deleteEvent Start...");
		int result = hcd.deleteEvent(eventId);
		
		System.out.println("HsCalServiceImpl deleteEvent result-> "+result);
		System.out.println("HsCalServiceImpl deleteEvent hcd.deleteEvent After...");
		return result;
	}

	@Override
	public List<Attendee> listReqAtten(Attendee attendee) {
		List<Attendee> listReqAttendee = null;
		System.out.println("HsCalServiceImpl listReqAtten Start...");
		listReqAttendee = hcd.listReqAtten(attendee);
		System.out.println("HsCalServiceImpl listReqAtten End...");
		return listReqAttendee;
	}

	@Override
	public int updateAttAcc(Attendee attendee) {
		System.out.println("HsCalServiceImpl updateAttAcc Start...");
		int updateCount=0;
		updateCount = hcd.updateAttAcc(attendee);
		System.out.println("HsCalServiceImpl updateAttAcc updateCount -> "+updateCount);
		System.out.println("HsCalServiceImpl updateAttAcc After...");
		return updateCount;
	}

	@Override
	public int updateAttRej(Attendee attendee) {
		System.out.println("HsCalServiceImpl updateAttRej Start...");
		int updateCount=0;
		updateCount = hcd.updateAttRej(attendee);
		System.out.println("HsCalServiceImpl updateAttRej updateCount -> "+updateCount);
		System.out.println("HsCalServiceImpl updateAttRej After...");
		return updateCount;
	}

	@Override
	public List<Attendee> listResAtten(Attendee attendee) {
		List<Attendee> listResAttendee = null;
		System.out.println("HsCalServiceImpl listResAtten Start...");
		listResAttendee = hcd.listResAtten(attendee);
		System.out.println("HsCalServiceImpl listResAtten End...");
		return listResAttendee;
	}
}
