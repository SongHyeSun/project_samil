package com.oracle.samil.TrDao;

import java.util.List;
import java.util.Map;

import com.oracle.samil.Amodel.Dept;
import com.oracle.samil.Amodel.Emp;
import com.oracle.samil.Adto.EmpDept;
import com.oracle.samil.Amodel.LoginInfo;

public interface EmpDao {

	Emp findEmpbyEmpno(String empno);

	LoginInfo findPassbyQuiz(int passQuiz, String passAnswer, String empno);

	List<Dept> selectDeptList();

	int insertEmp(Emp emp);

	List<Emp> selectEmpList();

	List<EmpDept> selectEmpDeptList();

	EmpDept findEmpDept(String emp1empno);

	int updateEmp(Emp emp);

	List<EmpDept> searchByKeyword(String keyword);

	List<EmpDept> showDeptMember(int deptno);

	List<Emp> listdeptEmp(int deptno);

	List<EmpDept> searchList(EmpDept empde);

	List<Map<String, Object>> autocomplete(Map<String, Object> paramMap);

	Emp searhEmpCal(int empno);
	
	

}
