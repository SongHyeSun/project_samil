package com.oracle.samil.TrService;

import java.util.List;

import org.springframework.stereotype.Service;

import com.oracle.samil.Amodel.Dept;
import com.oracle.samil.Amodel.Emp;
import com.oracle.samil.TrDao.EmpDao;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmpServiceImpl implements EmpService {
	
	private final EmpDao    ed;

	@Override
	public boolean validateUser(String empno, String password) {

		return true;
	}

	@Override
	public Emp findEmpbyEmpno(String empno) {
		System.out.println("findEmpbyEmpno->"+empno);
		Emp emp= ed.findEmpbyEmpno(empno);
		return emp;
	}

	@Override
	public List<Dept> listdept(Dept dept) {
		System.out.println("EmpServiceImpl listdept Start...");
		List<Dept> deptList = null;
		deptList = ed.listdept(dept);
		
		System.out.println("EmpServiceImpl listdept After");
		return deptList;
	}

	@Override
	public List<Emp> listdeptEmp(int deptno) {
		List<Emp> empDeptList = null;
		System.out.println("EmpServiceImpl listdeptEmp Start...");
		empDeptList = ed.listdeptEmp(deptno);
		
		System.out.println("EmpServiceImpl listdeptEmp After...");
		return empDeptList;
	}

}
