package com.oracle.samil.TrDao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.oracle.samil.Amodel.Dept;
import com.oracle.samil.Amodel.Emp;
import com.oracle.samil.Amodel.Event;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class EmpDaoImpl implements EmpDao {

	private final SqlSession session;
	
	@Override
	public Emp findEmpbyEmpno(String empno) {
		System.out.println("asd"+empno);
		System.out.println("findEmpbyEmpno start..");
		Emp emp = new Emp();
		try {
			System.out.println("findEmpbyEmpno ->"+empno);
			emp = session.selectOne("trEmpSelect",    empno);
			
		} catch (Exception e) {
			System.out.println("EmpDaoImpl detail Exception->"+e.getMessage());
		}
		return emp;
	}

	@Override
	public List<Dept> listdept(Dept dept) {
		List<Dept> deptList = null;
		System.out.println("EmpDaoImpl listdept Start...");

		try {
			deptList = session.selectList("tkDeptListAll",dept);
			System.out.println("EmpDaoImpl listdept deptList.size()-> "+deptList.size());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("EmpDaoImpl listdept e.getMessage()-> "+e.getMessage());
		}
		return deptList;
	}

	@Override
	public List<Emp> listdeptEmp(int deptno) {
		List<Emp> empDeptlist = null;
		System.out.println("EmpDaoImpl listdeptEmp Start...");

		try {
			empDeptlist = session.selectList("tkEmpDeptListAll",deptno);
			System.out.println("EmpDaoImpl listdeptEmp empDeptlist.size()-> "+empDeptlist.size());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("EmpDaoImpl listdeptEmp e.getMessage()-> "+e.getMessage());
		}
		return empDeptlist;
	}

}
