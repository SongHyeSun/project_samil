package com.oracle.samil.TrService;

import java.util.List;

import com.oracle.samil.Amodel.Dept;
import com.oracle.samil.Amodel.Emp;

public interface EmpService {

	boolean validateUser(String empno, String password);

	Emp findEmpbyEmpno(String empno);
	
	//주소록 부서목록
	List<Dept> listdept(Dept dept);
	//주소록 부서별 직원목록
	List<Emp> listdeptEmp(int deptno);

}
