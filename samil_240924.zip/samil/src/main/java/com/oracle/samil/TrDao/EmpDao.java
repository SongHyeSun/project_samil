package com.oracle.samil.TrDao;

import java.util.List;

import com.oracle.samil.Amodel.Dept;
import com.oracle.samil.Amodel.Emp;

public interface EmpDao {

	Emp findEmpbyEmpno(String empno);

	List<Dept> listdept(Dept dept);

	List<Emp> listdeptEmp(int deptno);
	
	

}
