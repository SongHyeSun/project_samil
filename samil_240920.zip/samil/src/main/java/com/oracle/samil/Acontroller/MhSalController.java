package com.oracle.samil.Acontroller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value="/mh")
public class MhSalController {
		
		@GetMapping(value = "/sal_join")
		public String sal_join (){
			System.out.println("mh sal_join play~");
			return "mh/sal_join";
		}
	
		@GetMapping(value = "/admin_sal_set")
		public String admin_sal_set (){
			System.out.println("mh admin_sal_set play~");
			return "mh/admin_sal_set";
		}
		
		@GetMapping(value = "/admin_sal_give")
		public String sal_give (){
			System.out.println("mh admin_sal_give play~");
			return "mh/admin_sal_give";
		}
		
		@GetMapping(value = "/admin_sal_list")
		public String sal_list (){
			System.out.println("mh admin_sal_list play~");
			return "mh/admin_sal_list";
		}

	
}
