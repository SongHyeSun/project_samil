package com.oracle.samil.HeService;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.oracle.samil.Amodel.Attendance;
import com.oracle.samil.Amodel.Emp;
import com.oracle.samil.Amodel.FurloughDetails;
import com.oracle.samil.HeDao.AttDao;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AttServiceImpl implements AttService {

	private final AttDao ad;

	@Override
	public List<Emp> myInfo(int empno) {
		return ad.myInfo(empno);
	}

	@Override
	public List<Attendance> myAttList(int empno) {
		System.out.println("  AttServiceImpl myAttList");
		List<Attendance> myAtt = ad.myAttList(empno);
		System.out.println("   AttServiceImpl myAttList myAtt : " + myAtt.size());
		return myAtt;
	}

	@Override
	public List<Attendance> myAttMList(int empno) {
		System.out.println("  AttServiceImpl myAttList");
		List<Attendance> myAttM = ad.myAttMList(empno);
		System.out.println("   AttServiceImpl myAttMList myAttM : " + myAttM.size());
		return myAttM;
	}

	@Override
	public int totalVacation(int empno) {
		System.out.println("  AttServiceImpl totalVacation");
		return ad.totalVacation(empno);
	}

	@Override
	public int restVacation(int empno) {
		System.out.println("  AttServiceImpl restVacation");
		return ad.restVacation(empno);
	}

	@Override
	public List<FurloughDetails> myLeaveList() {
		System.out.println("  AttServiceImpl empAttList");
		return ad.myLeaveList();
	}

	@Override
	public List<FurloughDetails> deptLeaveList(FurloughDetails furloughDetails) {
		System.out.println("  AttServiceImpl deptLeaveList");
		return ad.deptLeaveList(furloughDetails);
	}

	@Override
	public List<Map<String, Object>> deptStatusList(Integer statusCode) {
		return ad.deptStatusList(statusCode);
	}

	@Override
	public List<Map<String, Object>> deptAttByNameStatus(Map<String, Object> params) {
		return ad.deptAttByNameStatus(params);
	}
}
