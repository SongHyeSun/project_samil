package com.oracle.samil.HsDao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.oracle.samil.Amodel.Event;
import com.oracle.samil.Amodel.FacilApprove;
import com.oracle.samil.Amodel.Reservation;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class HsResDaoImpl implements HsResDao {
	
	@Autowired
	private final SqlSession session;

	@Override
	public List<Reservation> listload(Reservation res) {
		List<Reservation> listload = null;
		System.out.println("HsResDaoImpl listload Start...");
		try {
			listload = session.selectList("tkResListLoad",res);
			System.out.println("HsResDaoImpl listload listload.size()-> "+listload.size());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsResDaoImpl listload e.getMessage()-> "+e.getMessage());
		}
		
		System.out.println("HsResDaoImpl listload End...");
		return listload;
	}

	@Override
	public List<FacilApprove> listFacilAcc(FacilApprove faAp) {
		List<FacilApprove> listFacilAcc = null;
		System.out.println("HsResDaoImpl listFacilAcc Start...");
		try {
			listFacilAcc = session.selectList("tkResListAcc",faAp);
			System.out.println("HsResDaoImpl listFacilAcc listload.size()-> "+listFacilAcc.size());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsResDaoImpl listFacilAcc e.getMessage()-> "+e.getMessage());
		}
		
		System.out.println("HsResDaoImpl listFacilAcc End...");
		return listFacilAcc;
	}

	@Override
	public List<FacilApprove> listFacilRej(FacilApprove faAp) {
		List<FacilApprove> listFacilRej = null;
		System.out.println("HsResDaoImpl listFacilRej Start...");
		try {
			listFacilRej = session.selectList("tkResListRej",faAp);
			System.out.println("HsResDaoImpl listFacilRej listFacilRej.size()-> "+listFacilRej.size());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("HsResDaoImpl listFacilRej e.getMessage()-> "+e.getMessage());
		}
		
		System.out.println("HsResDaoImpl listFacilRej End...");
		return listFacilRej;
	}

	@Override
	public int insertReserv(Reservation res) {
		int result = 0;
		System.out.println("HsResDaoImpl insertReserv Start...");
		
		try {
			result = session.insert("tkReserInsert", res);
			System.out.println("HsResDaoImpl insertReserv res-> "+res);
		} catch (Exception e) {
			System.out.println("HsResDaoImpl insertReserv e.getMessage()-> "+e.getMessage());
		}
		return result;
	}

	@Override
	public int updateReserv(Reservation res) {
		int updateCount = 0;
		System.out.println("HsResDaoImpl updateReserv Start...");
		
		
		try {
			updateCount = session.update("tkupdateReserv", res);
			System.out.println("HsResDaoImpl updateReserv updateCount-> "+updateCount);
		} catch (Exception e) {
			System.out.println("HsResDaoImpl updateReserv e.getMessage()-> "+e.getMessage());
		}
		return updateCount;
	}

	@Override
	public Reservation detailRes(int resCode) {
		Reservation res = new Reservation();
		System.out.println("HsResDaoImpl detailRes Start...");
		try {
			res = session.selectOne("tkResSelOne", resCode);
			System.out.println("HsResDaoImpl detailRes event-> "+res);
			
		} catch (Exception e) {
			System.out.println("HsResDaoImpl detailRes e.getMessage()-> "+e.getMessage());
		}
		System.out.println("HsResDaoImpl detailRes End...");
		return res;
	}

	@Override
	public int deleteRes(int resCode) {
		int result = 0;
		System.out.println("HsResDaoImpl deleteRes Start...");
		System.out.println("HsResDaoImpl deleteRes resCode->" +resCode);
		try {
			result = session.delete("tkResDelete", resCode);
			System.out.println("HsResDaoImpl deleteRes result-> "+result);
		} catch (Exception e) {
			System.out.println("HsResDaoImpl deleteRes e.getMessage()-> "+e.getMessage());
		}
		return result;
	}

	@Override
	public List<Reservation> listfacil(Reservation res) {
		List<Reservation> reserList = null;
		System.out.println("HsResDaoImpl listfacil Start...");
		try {
			reserList = session.selectList("tkResListAppr",res);
			System.out.println("HsResDaoImpl listfacil reserList.size()-> "+reserList.size());
		} catch (Exception e) {
			System.out.println("HsResDaoImpl listfacil e.getMessage()-> "+e.getMessage());
		}
		
		System.out.println("HsResDaoImpl listfacil End...");
		return reserList;
	}


}
