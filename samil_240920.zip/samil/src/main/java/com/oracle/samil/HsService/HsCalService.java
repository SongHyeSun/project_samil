package com.oracle.samil.HsService;

import java.util.List;

import com.oracle.samil.Amodel.Attendee;
import com.oracle.samil.Amodel.Event;
import com.oracle.samil.Amodel.Reservation;

public interface HsCalService {

	List<Event> 	listEvent(Event event);
	Event 			detailEvent(int eventId);
	int 			updateEvent(Event event);
	int 			insertEvent(Event event);
	int 			deleteEvent(Event event);
	List<Attendee> 	listReqAtten(Attendee attendee);
	int 			updateAttAcc(Attendee attendee);
	int 			updateAttRej(Attendee attendee);
	List<Attendee> 	listResAtten(Attendee attendee);
	int 			eventRestore(Event event);
	int 			eventForever(int eventId);
	List<Event> 	listDelete(Event event);
	
	//admin
	List<Event> 	listAdEve(Event event);
	Event 			detailAdEvent(int eventId);
	int 			deleteAdEvent(int eventId);
}
